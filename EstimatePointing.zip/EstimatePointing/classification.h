/* 
/ ���p�F�R���s���[�^�r�W�����Ő�[�K�C�h2�@�\Mean-Shift, Kernel Method, Local Image Features, GPU�\
/ URL : http://opluse.shop-pro.jp/?pid=21043524
/ ��1�� �u���̔F���̂��߂̉摜�Ǐ������ʁv�@���g�@�O�j�C�R�����`
/ HOG�����ʂ�Real AdaBoost��p�������̌��o�̃v���O����
*/
#pragma once

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>


#define MAX_WEAK_CLASSIFIER		500
#define BIN						128	

const int POS = 1;
const int NEG = 0;

const std::string PDF_DIR = "./pdf/";
const std::string DIR_WEAK_CLASSIFIER = "./classifier.txt";

//�㎯�ʊ�
typedef struct _WeakClassifier{
	double z;					//�G���[��
	double dPdf[BIN][2];		//�m�����x�֐�
	int iFeatureNum;			//�����ʂ̔ԍ�
}WeakClassifier;


static int readWeakClassifier(WeakClassifier *cl, cv::HOGDescriptor &hog, double &dEpsilon){

  // classifier�ǂݍ���
  {
    std::ifstream ifs(DIR_WEAK_CLASSIFIER.c_str());
    if(!ifs.is_open()){
      std::cout << "can not open classifier file." << std::endl;
      exit(1);
    }
    ifs >> dEpsilon;

    cv::Size winSize, blockSize, blockStride, cellSize;
    int nbins;

    ifs >> winSize.width     >> winSize.height;
    ifs >> blockSize.width   >> blockSize.height;
    ifs >> blockStride.width >> blockStride.height;
    ifs >> cellSize.width    >> cellSize.height;
    ifs >> nbins;

    hog = cv::HOGDescriptor(winSize, blockSize, blockStride, cellSize, nbins, 1, -1, 0, 0.2, true);

    for(int i = 0; i < MAX_WEAK_CLASSIFIER; i++){
      ifs >> cl[i].iFeatureNum >> cl[i].z;
    }
  }

  // pdf�ǂݍ���
  for(int i = 0; i < MAX_WEAK_CLASSIFIER; i++){
    std::stringstream ss;
    ss << PDF_DIR << i << ".txt";
    std::ifstream ifs(ss.str().c_str());

    if(!ifs.is_open()){
      std::cout << "can not open pdf file." << std::endl;
      exit(1);
    }
    for(int j = 0; j < BIN; j++){
      ifs >> cl[i].dPdf[j][POS] >> cl[i].dPdf[j][NEG];
    }

  }
	return 0;
}

// �㎯�ʊ�̏o�͂��Z�o
static double prediction(float dFeature, double dPdf[][2], double dEpsilon){
	int tmp;
	double h = 0.0;

	//�����ʂ�ʎq��
	tmp = (int)(dFeature * BIN);
	if(tmp < 0){
		tmp = 0;
	}
	if(tmp >= BIN){
		tmp = BIN - 1;
	}

	h += log((dPdf[tmp][POS] + dEpsilon)/(dPdf[tmp][NEG] + dEpsilon));

	h *= 0.5;

	return h;
}

// �ǉ�
#include "CV.h"

class Detector{
public:
  Detector() :
      cl(NULL), hog(), dEpsilon(0)
  {
  }

  ~Detector()
  {
    if(cl != NULL)
      delete cl;
  }

  void init(const std::string &filename)
  {
    cl = new WeakClassifier [MAX_WEAK_CLASSIFIER];
    readWeakClassifier(cl, hog, dEpsilon);
  }

  inline int detect(const cv::Mat &img, double threshold)
  {
    std::vector<float> features;
    hog.compute(img, features);
    double dResponse = 0;
    for(int i = 0; i < MAX_WEAK_CLASSIFIER; i++){
      dResponse += prediction(features[cl[i].iFeatureNum], cl[i].dPdf, dEpsilon);
    }
    if(dResponse > threshold)
      return 1;
    else
      return 0;
  }

private:
  WeakClassifier *cl;
  cv::HOGDescriptor hog;
  double dEpsilon;

};