// -*- C++ -*-
/*!
 * @file  EstimatePointing.cpp
 * @brief estimate pointing position and direction
 * @date $Date$
 *
 * $Id$
 */

#include "EstimatePointing.h"
#include <algorithm>

using std::cout;
using std::endl;

inline cv::Mat getForeground(cv::BackgroundSubtractorMOG2 &mog, cv::Mat &img)
{
  assert( img.depth() == CV_8U && img.channels() == 3 );
  cv::Mat fg;
  mog(img, fg, -1);
  return fg;
}

template <typename T> inline double distance(const cv::Point_<T> &p1, const cv::Point_<T> &p2)
{
  return std::sqrt( (double)(p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y) );
}


// Module specification
// <rtc-template block="module_spec">
static const char* estimatepointing_spec[] =
  {
    "implementation_id", "EstimatePointing",
    "type_name",         "EstimatePointing",
    "description",       "estimate pointing position and direction",
    "version",           "1.0.0",
    "vendor",            "AIS",
    "category",          "Computer Vision",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.string_skin_model_file", "skin_model.txt",
    "conf.default.string_subtraction_file", "subtraction.txt",
    "conf.default.bool_image_window_flag", "1",
    // Widget
    "conf.__widget__.string_skin_model_file", "text",
    "conf.__widget__.string_subtraction_file", "text",
    "conf.__widget__.bool_image_window_flag", "radio",
    // Constraints
    "conf.__constraints__.bool_image_window_flag", "(0,1)",
    ""
  };
// </rtc-template>


//class MY : public RTC::ConnectionCallback{
//  void operator()(RTC::ConnectorProfile& profile){
//    flag1++;
//  };
//};
//MY *m;

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
EstimatePointing::EstimatePointing(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_Input1In("Input1", m_Input1),
    m_Input2In("Input2", m_Input2),
    m_PositionOut("Position", m_Position),
    m_DirectionOut("Direction", m_Direction),
    m_CameraCaptureServicePort("CameraCaptureService")

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
EstimatePointing::~EstimatePointing()
{
}



RTC::ReturnCode_t EstimatePointing::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("Input1", m_Input1In);
  addInPort("Input2", m_Input2In);
  
  // Set OutPort buffer
  addOutPort("Position", m_PositionOut);
  addOutPort("Direction", m_DirectionOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  m_CameraCaptureServicePort.registerConsumer("CameraCapture", "Img::CameraCaptureService", m_CameraCapture);
  
  // Set CORBA Service Ports
  addPort(m_CameraCaptureServicePort);
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("string_skin_model_file", m_string_skin_model_file, "skin_model.txt");
  bindParameter("string_subtraction_file", m_string_subtraction_file, "subtraction.txt");
  bindParameter("bool_image_window_flag", m_bool_image_window_flag, "1");

  state[0].setPort(m_Input1In);
  state[1].setPort(m_Input2In);

  flag[0] = flag[1] = 0;

  image[0] = cv::Mat::zeros(480, 640, CV_8UC3);
  image[1] = cv::Mat::zeros(480, 640, CV_8UC3);

  img2Type = IMAGE_TYPE::TYPE_UNKNOWN;
  detector.init(DIR_WEAK_CLASSIFIER);

  // </rtc-template>
  return RTC::RTC_OK;
}


RTC::ReturnCode_t EstimatePointing::onFinalize()
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t EstimatePointing::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t EstimatePointing::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t EstimatePointing::onActivated(RTC::UniqueId ec_id)
{
  imgmask.readFile("mask.txt");
  result = new short [640 * 480];

  return RTC::RTC_OK;
}


RTC::ReturnCode_t EstimatePointing::onDeactivated(RTC::UniqueId ec_id)
{

  imgmask.writeFile("mask.txt");
  delete result;

  cv::destroyAllWindows();
  flag[0] = flag[1] = 0;
  return RTC::RTC_OK;
}


RTC::ReturnCode_t EstimatePointing::onExecute(RTC::UniqueId ec_id)
{
  if(state[0].flag == 0 && flag[0] == 1){
    flag[0] = 0;
    if(m_bool_image_window_flag) cv::destroyWindow("camera1");
  }
  if(state[1].flag == 0 && flag[1] == 1){
    flag[1] = 0; img2Type = TYPE_UNKNOWN;
    if(m_bool_image_window_flag) cv::destroyWindow("camera2");
  }

  // �摜�擾�i�J�����P�j
  if(m_Input1In.isNew()){
    m_Input1In.read();
    
    if(m_Input1.data.image.format != Img::CF_RGB) return RTC::RTC_ERROR;

    if(flag[0] == 0){
      image[0] = cv::Mat(m_Input1.data.image.height, m_Input1.data.image.width, CV_8UC3, &m_Input1.data.image.raw_data[0]);
      ReadCameraParam(m_Input1, 0);
      flag[0] = 1;
      if(m_bool_image_window_flag) cv::namedWindow("camera1");
    }

  }else{
    std::cout << "camera 1 : capture faled." << std::endl;
  }

  // �摜�擾�i�J�����Q�j
  if(m_Input2In.isNew()){
    m_Input2In.read();

    if(flag[1] == 0){
      ReadCameraParam(m_Input2, 1);
      flag[1] = 1;
      if(m_bool_image_window_flag) cv::namedWindow("camera2");
    }

    if(m_Input2.data.image.format == Img::CF_RGB && img2Type != TYPE_COLOR){
      image[1] = cv::Mat(m_Input2.data.image.height, m_Input2.data.image.width, CV_8UC3, &m_Input2.data.image.raw_data[0]);
      img2Type = TYPE_COLOR;
    }else if(m_Input2.data.image.format == Img::CF_UNKNOWN && img2Type != TYPE_DEPTH){
      int depth = m_Input2.data.image.raw_data.length() / m_Input2.data.image.width / m_Input2.data.image.height;
      if(depth == 2){
        image[1] = cv::Mat(m_Input2.data.image.height, m_Input2.data.image.width, CV_16U, &m_Input2.data.image.raw_data[0]);
        img2Type = TYPE_DEPTH;
      }else{
        return RTC::RTC_ERROR;
      }
    }else if(m_Input2.data.image.format == Img::CF_GRAY){
      return RTC::RTC_ERROR;
    }

  }else{
    std::cout << "camera 2 : capture faled." << std::endl;
  }

  if(!state[0].flag)
    return RTC::RTC_OK;

  RTC::Point3D point;
  RTC::Vector3D vector;

  Calc_PosAndDir(point, vector);

  cout << "(x,y,z) = " << point.x << " , " << point.y << " , " << point.z << endl;

  if(m_bool_image_window_flag){
    if(flag[0]) cv::imshow("camera1", image[0]);
    if(flag[1]){
      cv::Mat temp;
      image[1].convertTo(temp, CV_8U, 220/5000. );
      cv::imshow("camera2", temp);
    }
    cv::waitKey(5);
  }

  return RTC::RTC_OK;
}


RTC::ReturnCode_t EstimatePointing::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t EstimatePointing::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t EstimatePointing::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t EstimatePointing::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t EstimatePointing::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

void EstimatePointing::ReadCameraParam(Img::TimedCameraImage &input, const int index)
{
  cv::Mat intrinsic, distortion, extrinsic;
  intrinsic = cv::Mat::eye(3, 3, CV_64F);
  intrinsic.at<double>(0,0) = input.data.intrinsic.matrix_element[0];
  intrinsic.at<double>(0,1) = input.data.intrinsic.matrix_element[1];
  intrinsic.at<double>(1,1) = input.data.intrinsic.matrix_element[2];
  intrinsic.at<double>(0,2) = input.data.intrinsic.matrix_element[3];
  intrinsic.at<double>(1,2) = input.data.intrinsic.matrix_element[4];

  if(input.data.intrinsic.distortion_coefficient.length() != 0)
    distortion = cv::Mat(1, (int)input.data.intrinsic.distortion_coefficient.length(), CV_64F, &input.data.intrinsic.distortion_coefficient[0]);
  else
    distortion = cv::Mat::zeros(1, 5, CV_64F);

  extrinsic = cv::Mat(4, 4, CV_64F, &input.data.extrinsic[0][0]);

  camParam[index].paramSet(intrinsic, distortion, extrinsic);
  std::cout << camParam[index].getCamPos() << std::endl;

}

cv::Mat EstimatePointing::DetectBasePoint(const int id, cv::Point *outP)
{

  const static cv::Point2f dstPnt[4] = { cv::Point2f(36,0), cv::Point2f(36,36), cv::Point2f(0,36), cv::Point2f(0,0) };

  cv::Mat img = image[id].clone();

  cv::Mat gray;
  cv::cvtColor(img, gray, CV_RGB2GRAY);
  cv::equalizeHist(gray, gray);

  cv::Mat skin = imgmask.calcMask(img);
  cv::Mat fg   = getForeground(mog[id], img);

  cv::threshold(fg, fg, 1, 255, CV_THRESH_BINARY);

  cv::Mat mask;
  cv::bitwise_and(skin, fg, mask);

  cv::medianBlur(mask, mask, 3);
  cv::medianBlur(mask, mask, 3);

  label.Exec(mask.data, result, 640, 480, true, 400);

  cv::Mat mask2;
  for(int i = 0; i < label.GetNumOfResultRegions(); i++){
    cv::inRange(cv::Mat(480,640,CV_16S,result), cv::Mat::ones(480,640,CV_16S)*(i+1), cv::Mat::ones(480,640,CV_16S)*(i+1), mask2);
    mask2.convertTo(mask2, CV_8U);

    cv::Moments m = cv::moments(mask2, true);
    int pixs = (int)m.m00;
    cv::Point2d grav(m.m10/pixs, m.m01/pixs);

    // ��_�Z�o
    cv::Rect rect;
    cv::Point maxP;
    {
      RegionInfoBS *ri = label.GetResultRegionInfo(i);
      ri->GetMin(rect.x, rect.y); ri->GetSize(rect.width, rect.height);
      double max = 0;
      for(int y = rect.y; y < rect.br().y-1; y++){
        for(int x = 0; x < rect.br().x-1; x++){
          if(mask2.at<uchar>(y,x) != 0){
            double val = distance(grav, cv::Point2d(x,y));
            if(max < val){
              max = val;
              maxP = cv::Point(x,y);
            }
          }
        }
      }
    }

    // �X�P�[���Z�o�̏���
    cv::Mat eigenVec, eigenVal;
    {
      cv::Mat vcMat = (cv::Mat_<double>(2,2)<< m.mu20/pixs, m.mu11/pixs, m.mu11/pixs, m.mu02/pixs);
      cv::eigen( vcMat, eigenVal, eigenVec);
    }
    double dx = (maxP.x > grav.x) ? std::abs(eigenVec.at<double>(0,0)) : -1 * std::abs(eigenVec.at<double>(0,0));
    double dy = (maxP.y > grav.y) ? std::abs(eigenVec.at<double>(0,1)) : -1 * std::abs(eigenVec.at<double>(0,1));

    std::vector<double> prj(pixs);
    {
      int count = 0;
      for(int y = rect.y; y < rect.br().y-1; y++){
        for(int x = 0; x < rect.br().x-1; x++){
          if(mask2.at<uchar>(y,x) != 0){
            prj[count++] = dx * (x-grav.x) + dy * (y-grav.y);
          }
        }
      }
      std::sort(prj.begin(), prj.end());
    }

    // �X�P�[���Z�o
    int size = 20;
    cv::Point2f center;
    float temp = (maxP.x-grav.x) * dx + (maxP.y-grav.y) * dy;
    center.x = grav.x + ( (maxP.x-grav.x)*dx + (maxP.y-grav.y)*dy ) * dx;
    center.y = grav.y + ( (maxP.x-grav.x)*dx + (maxP.y-grav.y)*dy ) * dy;

    std::vector<double>::reverse_iterator it = prj.rbegin(), end = prj.rend();
    for(temp-=size; ; size++, temp--){
      int count = 0;
      while(1){
        count++; ++it;
        if(it == end || *it < temp) break;
      }
      if((float)count / (float)(size*size) < 0.005 || it == end) break;
    }

    // ��`��4�_���Z�o
    cv::Point2f pnt[4];
    {
      float theta = std::atan2(dy, dx) + CV_PI;
      cv::Point2f temp;
      temp.x = center.x+size/2.0*std::cos(theta);
      temp.y = center.y+size/2.0*std::sin(theta);
      cv::RotatedRect r(temp, cv::Size2f(size, size), theta*180/CV_PI);
      r.points(pnt);
    }

    // ��̈�̐؂�o��
    cv::Mat dstImg;
    {
      cv::Mat temp;
      cv::Mat warp = cv::getPerspectiveTransform(pnt, dstPnt);
      gray.copyTo(temp, mask2);
      cv::warpPerspective(temp, dstImg, warp, cv::Size(36,36), CV_INTER_LANCZOS4);

      cv::Moments mm = cv::moments(dstImg, true);
      cv::Point2d dst_grav(mm.m10/mm.m00, mm.m01/mm.m00);
      if( 36/2. < dst_grav.x )
        cv::flip(dstImg, dstImg, 1);
      if( 36/2. < dst_grav.y)
        cv::flip(dstImg, dstImg, 0);


      if(detector.detect(dstImg, 0.)){
        outP[0] = cv::Point(grav);
        outP[1] = cv::Point(maxP);
//*
        cv::line(image[0], cv::Point(pnt[0]), cv::Point(pnt[1]), CV_RGB(255,0,0), 2);
        cv::line(image[0], cv::Point(pnt[2]), cv::Point(pnt[1]), CV_RGB(255,0,0), 2);
        cv::line(image[0], cv::Point(pnt[2]), cv::Point(pnt[3]), CV_RGB(255,0,0), 2);
        cv::line(image[0], cv::Point(pnt[0]), cv::Point(pnt[3]), CV_RGB(255,0,0), 2);
//*/
        return mask2;
      }

    }
    
  }

  outP[0] = cv::Point(0,0);
  outP[1] = cv::Point(0,0);
  return cv::Mat::zeros(480,640,CV_8U);

}

void EstimatePointing::Calc_PosAndDir(Point3D &point, Vector3D &vector)
{
  // �J�����P��_�Z�o
  cv::Point basePnt1[2];
  cv::Mat mask = DetectBasePoint( 0, basePnt1 );


  if(state[1].flag){
    if(img2Type == TYPE_COLOR){
      cv::Point basePnt2[2];
      DetectBasePoint( 1, basePnt2 );

      if(basePnt1[0] == cv::Point(0,0) && basePnt1[1] == cv::Point(0,0)){
        cout << "base point is not found from camera 1." << endl;
        point.x = point.y = point.y = vector.x = vector.y = vector.z = 0;
        return;
      }
      if(basePnt2[0] == cv::Point(0,0) && basePnt2[1] == cv::Point(0,0)){
        cout << "base point is not found from camera 2." << endl;
        point.x = point.y = point.y = vector.x = vector.y = vector.z = 0;
        return;
      }
      // cam1�v�Z�@�J�������C�Ɗ�_���Ȃ��������L�����u���[�V�������ʂƌ�������3D�_ , �J�����ʒu�ƕ����̂Ȃ����ʂ̖@���x�N�g��
      cv::Point2d p1 = camParam[0].calcWorldPos(basePnt1[0]);
      cv::Vec3d   v1 = camParam[0].calcNormalVec(basePnt1[0], basePnt1[1]);
      cv::Point3d c1 = cv::Point3d(camParam[0].getCamPos());

      cout << "wldPos1 : " << p1 << endl;
      cout << "nVec1   : " << v1 << endl;
      cout << "camPos1 : " << c1 << endl;

      // cam2�v�Z
      cv::Point2d p2 = camParam[1].calcWorldPos(basePnt2[0]);
      cv::Vec3d   v2 = camParam[1].calcNormalVec(basePnt2[0], basePnt2[1]);
      cv::Point3d c2 = cv::Point3d(camParam[1].getCamPos());

      cout << "wldPos2 : " << p2 << endl;
      cout << "nVec2   : " << v2 << endl;
      cout << "camPos2 : " << c2 << endl;

      // �ʒu�E�����Z�o
      double dx1 = c1.x - p1.x;
      double dx2 = c2.x - p2.x;
      double dx3 = p1.x - p2.x;

      double dy1 = c1.y - p1.y;
      double dy2 = c2.y - p2.y;
      double dy3 = p1.y - p2.y;

      double dz1 = c1.z;
      double dz2 = c2.z;
      double dz3 = 0;

	    double a, b, c, d, p, q;
	    // ��f/��t=0
	    a = dx1*dx1 + dy1*dy1 + dz1*dz1;
	    b = (-1*dx1*dx2) + (-1*dy1*dy2) + (-1*dz1*dz2);
	    p = (-1*dx1*dx3) + (-1*dy1*dy3) + (-1*dz1*dz3);

	    // ��f/��s=0
	    c = (-1*dx1*dx2) + (-1*dy1*dy2) + (-1*dz1*dz2);
	    d = dx2*dx2 + dy2*dy2 + dz2*dz2;
	    q = (dx2*dx3) + (dy2*dy3) + (dz2*dz3);

      cv::Mat A = (cv::Mat_<double>(2,2) << a, b, c, d);
      cv::Mat P = (cv::Mat_<double>(2,1) << p, q);
    	cv::Mat X = A.inv() * P;

	    double t = X.at<double>(0,0);
	    double s = X.at<double>(1,0);

	    if( !(0<t&&t<1) ){
		    printf("�͈͊O\n");
	    }
	    if( !(0<s&&s<1) ){
		    printf("�͈͊O\n");
	    }

	    double dist = sqrt(pow((dx1*t+p1.x-dx2*s-p2.x), 2) + pow((dy1*t+p1.y-dy2*s-p2.y), 2) + pow((dz1*t-dz2*s), 2) );
	    std::cout << "distance : " << dist << std::endl;

      point.x = ( (dx1*t+p1.x) + (dx2*s+p2.x) ) / 2;
      point.y = ( (dy1*t+p1.y) + (dy2*s+p2.y) ) / 2;
      point.z = ( (dz1*t) + (dz2*s) ) / 2;

      cv::Vec3d dir = v1.cross(v2);
      double n = cv::norm(dir);

      vector.x = dir[0] / n;
      vector.y = dir[1] / n;
      vector.z = dir[2] / n;


    }else if(img2Type == TYPE_DEPTH){
      // depth����
      std::vector<cv::Point3d> pnts;
	    double avex, avey, avez;
	    avex = avey = avez = 0.0;
	    for(int y = 0; y < 480; y+=2){
		    for(int x = 0; x < 640; x+=2){
			    if(mask.at<uchar>(y,x) != 0){
            double dep = (double)image[1].at<ushort>(y,x);
				    if(dep != 0){
					    cv::Point3d pnt = camParam[0].calcWorldPos(cv::Point2d(x,y), dep);
					    if(pnt.z < 0) continue;
					    pnts.push_back(pnt);
					    avex += pnt.x; avey += pnt.y; avez += pnt.z;
				    }
			    }
		    }
	    }
	    double num = (double)pnts.size();
	    if(num != 0){
		    avex = avex / num; avey = avey / num; avez = avez / num;
		    // ���U�����U�s��Z�o
		    cv::Mat vcMat;
		    double xx, xy, xz, yy, yz, zz;
		    xx = xy = xz = yy = yz = zz = 0;
		    for(int i = 0; i < num; i++){
			    double X = pnts[i].x - avex;
			    double Y = pnts[i].y - avey;
			    double Z = pnts[i].z - avez;
			    xx+=X*X; xy+=X*Y; xz+=X*Z;
			    yy+=Y*Y; yz+=Y*Z; zz+=Z*Z;
		    }
		    vcMat = (cv::Mat_<double>(3,3) << xx/num, xy/num, xz/num, xy/num, yy/num, yz/num, xz/num, yz/num, zz/num);

        // �����i�厲�j�̌v�Z
     		cv::Mat eigenVal, eigenVec;
    		cv::eigen(vcMat, eigenVal, eigenVec);
        
        //��_�i�d�S�j�A�����i�厲�j
        point.x = avex; point.y = avey; point.z = avez;
        vector.x = eigenVec.at<double>(0,0);
        vector.y = eigenVec.at<double>(0,1);
        vector.z = eigenVec.at<double>(0,2);
      }else{
        cout << "error. depth." << endl;
        point.x = point.y = point.z = vector.x = vector.y = vector.z = 0.;
      }
    }else{
      assert("image 1 type is unknown.");
    }
  }else{
    assert("single camera.");
  }

}


extern "C"
{
 
  void EstimatePointingInit(RTC::Manager* manager)
  {
    coil::Properties profile(estimatepointing_spec);
    manager->registerFactory(profile,
                             RTC::Create<EstimatePointing>,
                             RTC::Delete<EstimatePointing>);
  }
  
};


