#pragma once

#include "CV.h"

class CamParam
{
private:
	cv::Mat _intr;
	cv::Mat _disC;
	cv::Mat _camP;
	cv::Mat _invI;
	cv::Mat _invE;
	cv::Mat _invA;
public:
	CamParam(){
	}

	CamParam(std::string intrinsic, std::string extrinsic){
		Init(intrinsic, extrinsic);
	}
	
	CamParam(CamParam &cam){
		(*this) = cam;
	}

	~CamParam(){
	}
	
	template <typename T> inline cv::Point2d calcWorldPos(const cv::Point_<T> &imgP){
		cv::Mat imgPos = (cv::Mat_<cv::Vec2d>(1,1) << cv::Vec2d(imgP.x, imgP.y));
		cv::Mat dstPos;
		cv::undistortPoints(imgPos, dstPos, _intr, _disC, cv::Mat(), _intr);

		cv::Vec2d vec = dstPos.at<cv::Vec2d>(0,0);

		cv::Mat pos = (cv::Mat_<double>(3,1) << (double)vec[0], (double)vec[1], 1.);
		
		cv::Mat wldPos = _invA * pos;

		cv::Point2d wldP;
		wldP.x = wldPos.at<double>(0,0) / wldPos.at<double>(2,0);
		wldP.y = wldPos.at<double>(1,0) / wldPos.at<double>(2,0);
		return wldP;
	}

	inline cv::Point3d calcWorldPos(const cv::Point2d &imgP, double &depth){
		cv::Point2d wldP = calcWorldPos(imgP);
		cv::Point3d dirVec;			// directional vector(�����x�N�g��)
		dirVec.x = wldP.x - _camP.at<double>(0,0);
		dirVec.y = wldP.y - _camP.at<double>(1,0);
		dirVec.z =      0 - _camP.at<double>(2,0);

		double rate = depth / cv::norm(dirVec);
		cv::Point3d position;
		position.x = _camP.at<double>(0,0) + dirVec.x * rate;
		position.y = _camP.at<double>(1,0) + dirVec.y * rate;
		position.z = _camP.at<double>(2,0) + dirVec.z * rate;
		return position;
	}

  template <typename T> inline cv::Mat img2worldCoord(const cv::Point_<T> ip){
    cv::Mat imgCoord = (cv::Mat_<double>(3,1) << ip.x, ip.y, 1.0);
    return ( _invA * imgCoord );
  }

  template <typename T> inline cv::Vec3d calcNormalVec(const cv::Point_<T> &p1, const cv::Point_<T> &p2){
    return cv::Vec3d((img2worldCoord(p1) - _camP).cross(img2worldCoord(p2) - _camP));
  }

	
	inline cv::Mat getIntMat(void){ return _intr; }
	inline cv::Mat getDisCoe(void){ return _disC; }
	inline cv::Mat getCamPos(void){ return _camP; }
	inline cv::Mat getInvInt(void){ return _invI; }
	inline cv::Mat getInvExt(void){ return _invE; }
	inline cv::Mat getInvARt(void){ return _invA; }

  //
  inline void paramSet(const cv::Mat &intr, const cv::Mat &dist, const cv::Mat &extr){
    _intr = intr;
    _disC = dist;
    _camP = -1 * extr(cv::Rect(0,0,3,3)).t() * extr(cv::Rect(3,0,1,3));
    _invI = intr.inv();
    _invE = extr.inv();

    cv::Mat_<double> tmp(extr);
    cv::Mat matRt = (cv::Mat_<double>(3,3) << tmp(0,0),tmp(0,1),tmp(0,3), tmp(1,0),tmp(1,1),tmp(1,3), tmp(2,0),tmp(2,1),tmp(2,3));
    std::cout << matRt << std::endl;
    _invA = (intr * matRt).inv();
  }
  //

private:
	void Init(const std::string intrinsic, const std::string extrinsic){
		cv::Mat cameraMatrix, distCoeffs, rotation, translation;
		cv::FileStorage fs;
		cv::FileNode node;

		fs.open(intrinsic, CV_STORAGE_READ);
		node = cv::FileNode(fs.fs, NULL);
		cv::read(node["cameraMatrix"], cameraMatrix);
		cv::read(node["distCoeffs"], distCoeffs);
		fs.release();

		fs.open(extrinsic, CV_STORAGE_READ);
		node = cv::FileNode(fs.fs, NULL);
		cv::read(node["rotation"], rotation);
		cv::read(node["translation"], translation);
		fs.release();

		cv::Mat rotMat;
		cv::Rodrigues(rotation, rotMat);

		////////////// �O���p�����[�^����� //////////////////
		cv::Mat extr(4, 4, CV_64F);
		// 1�s�� //
		extr.at<double>(0,0) = rotMat.at<double>(0,0);
		extr.at<double>(0,1) = rotMat.at<double>(0,1);
		extr.at<double>(0,2) = rotMat.at<double>(0,2);
		extr.at<double>(0,3) = translation.at<double>(0,0);
		// 2�s�� //
		extr.at<double>(1,0) = rotMat.at<double>(1,0);
		extr.at<double>(1,1) = rotMat.at<double>(1,1);
		extr.at<double>(1,2) = rotMat.at<double>(1,2);
		extr.at<double>(1,3) = translation.at<double>(0,1);
		// 3�s�� //
		extr.at<double>(2,0) = rotMat.at<double>(2,0);
		extr.at<double>(2,1) = rotMat.at<double>(2,1);
		extr.at<double>(2,2) = rotMat.at<double>(2,2);
		extr.at<double>(2,3) = translation.at<double>(0,2);
		// 4�s�� //
		extr.at<double>(3,0) = 0.0;
		extr.at<double>(3,1) = 0.0;
		extr.at<double>(3,2) = 0.0;
		extr.at<double>(3,3) = 1.0;

		////////////// [R|t]�̍쐬�i�����O���p�����[�^�s��j //////////////////
		cv::Mat matRt(3, 3, CV_64F);
		// 1�s�� //
		matRt.at<double>(0,0) = rotMat.at<double>(0,0);
		matRt.at<double>(0,1) = rotMat.at<double>(0,1);
		matRt.at<double>(0,2) = translation.at<double>(0,0);
		// 2�s�� //
		matRt.at<double>(1,0) = rotMat.at<double>(1,0);
		matRt.at<double>(1,1) = rotMat.at<double>(1,1);
		matRt.at<double>(1,2) = translation.at<double>(0,1);
		// 3�s�� //
		matRt.at<double>(2,0) = rotMat.at<double>(2,0);
		matRt.at<double>(2,1) = rotMat.at<double>(2,1);
		matRt.at<double>(2,2) = translation.at<double>(0,2);

		_intr = cameraMatrix;
		_disC = distCoeffs;
		_camP = -1*rotMat.t()*translation.t();
		_invI = cameraMatrix.inv();
		_invE = extr.inv();
		_invA = (cameraMatrix*matRt).inv();
	}
};
