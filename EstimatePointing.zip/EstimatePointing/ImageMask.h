#include <windows.h>
#include <iostream>
#include <fstream>
#include "CV.h"

class ImageMask
{
public:

#define MASK_SKIN 1

	enum
	{
		IMAGE_MASK_TYPE_RGB = 0,
		IMAGE_MASK_TYPE_HSV,
		IMAGE_MASK_TYPE_YCrCb
	};

private:
	int _imageType;
	int _cn[3];
	int _min[3];
	int _max[3];
	int _x;
	int _y;
	cv::Mat *_img;
public:
	ImageMask(int eType = IMAGE_MASK_TYPE_HSV)
	{
		_imageType = eType;
		_cn[0] = _cn[1] = _cn[2] = 1;
		_min[0] = _min[1] = _min[2] = 0;
		_max[0] = _max[1] = _max[2] = 256;
		_x = _y = 0;
		_img = 0;
	}
	~ImageMask()
	{
	}
  ImageMask(ImageMask &im)
  {
    (*this) = im;
  }
	void setChannels(int c0, int c1, int c2)
	{
		_cn[0] = c0;
		_cn[1] = c1;
		_cn[2] = c2;
	}
	void setValue(cv::Mat &img)
	{
    assert( img.depth() == CV_8U && img.channels() == 3 );
		_img = &img;
		createWindow();
		while(1){
			cv::imshow("ImageMask", calcMask(img));
			if(cv::waitKey(33) == 27) break;
		}
    _img = 0;
		cv::destroyWindow("ImageMask");
	}
	cv::Mat calcMask(const cv::Mat &img)
	{
    assert( img.depth() == CV_8U && img.channels() == 3 );
		cv::Mat cvt, tmp, dst = cv::Mat::ones(img.rows, img.cols, CV_8U);
		std::vector<cv::Mat> mv;

		cv::cvtColor(img, cvt, CV_BGR2HSV);
		cv::split(cvt, mv);
		for(int i = 0; i < (int)mv.size(); i++){
			if(!_cn[i]) continue;
      cv::inRange(mv[i], cv::Mat::ones(mv[i].size(), CV_8U)*_min[i], cv::Mat::ones(mv[i].size(), CV_8U)*_max[i], tmp);
			cv::bitwise_and(dst, tmp, dst);
		}
		dst = dst * 255;
		return dst;
	}

	void writeFile(const std::string &filename)
	{
		std::ofstream ofs(filename.c_str());
		ofs << _imageType << " " << \
			   _cn[0] << " " << _cn[1] << " " << _cn[2] << " " << \
			   _min[0] << " " << _min[1] << " " << _min[2] << " " << \
			   _max[0] << " " << _max[1] << " " << _max[2];
	}
	void readFile(const std::string &filename)
	{
		std::ifstream ifs(filename.c_str());
		ifs >> _imageType;
		ifs >> _cn[0] >> _cn[1] >> _cn[2];
		ifs >> _min[0] >> _min[1] >> _min[2];
		ifs >> _max[0] >> _max[1] >> _max[2];
	}
private:
	void createWindow()
	{
		cv::namedWindow("ImageMask",  CV_WINDOW_AUTOSIZE | CV_WINDOW_FREERATIO | CV_GUI_NORMAL);
		cvSetMouseCallback("ImageMask", onMouse, this);
		if(_cn[0]){
			cv::createTrackbar("c0_min", "ImageMask", &_min[0], 255, onTrackbar1, "0");
			cv::createTrackbar("c0_max", "ImageMask", &_max[0], 256, onTrackbar2, "0");
		}
		if(_cn[1]){
			cv::createTrackbar("c1_min", "ImageMask", &_min[1], 255, onTrackbar1, "1");
			cv::createTrackbar("c1_max", "ImageMask", &_max[1], 256, onTrackbar2, "1");
		}
		if(_cn[2]){
			cv::createTrackbar("c2_min", "ImageMask", &_min[2], 255, onTrackbar1, "2");
			cv::createTrackbar("c2_max", "ImageMask", &_max[2], 256, onTrackbar2, "2");
		}
	}
	static void onMouse(int event, int x, int y, int flags, void *param)
	{
		cv::Mat cvt;
	  cv::cvtColor(*(reinterpret_cast<ImageMask*>(param))->_img, cvt, CV_BGR2HSV);    // ���F�����₷�����邽�߂ɕύX

		std::cout << cvt.at<cv::Vec3b>(y,x) << std::endl;
	}
public:
	static void onTrackbar1(int pos, void *userData)
	{
		std::string str;
		if(userData == "0")		 str = "c0_max";
		else if(userData == "1") str = "c1_max";
		else					 str = "c2_max";

		if( pos >= cv::getTrackbarPos(str, "ImageMask") )
			cv::setTrackbarPos(str, "ImageMask", pos+1);
	}
	static void onTrackbar2(int pos, void *userData)
	{
		// max��0�ɂȂ�Ȃ��悤��
		if(pos == 0){
			std::string str;
			if(userData == "0")		 str = "c0_max";
			else if(userData == "1") str = "c1_max";
			else					 str = "c2_max";
			cv::setTrackbarPos(str, "ImageMask", 1);
		}

		std::string str;
		if(userData == "0")		 str = "c0_min";
		else if(userData == "1") str = "c1_min";
		else					 str = "c2_min";
		if( pos <= cv::getTrackbarPos(str, "ImageMask") )
			cv::setTrackbarPos(str, "ImageMask", pos-1);
	}
};
