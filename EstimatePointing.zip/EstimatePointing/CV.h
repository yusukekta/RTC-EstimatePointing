#pragma once
// warning C4996 'strcmp' �𖳎����邽�߁@[ strcmp() --> strcpy_s() �ɒu������ ]
//http://d.hatena.ne.jp/maginemu/20090411/1239458459
//#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1
#pragma warning( disable: 4996 )

#include <iostream>

//*
#include <opencv2/opencv.hpp>
#include <opencv2/gpu/gpu.hpp>

#ifdef _DEBUG
	//Debug���[�h�̏ꍇ
	#pragma comment(lib,"opencv_core230d.lib")
	#pragma comment(lib,"opencv_imgproc230d.lib")
	#pragma comment(lib,"opencv_highgui230d.lib")
	#pragma comment(lib,"opencv_calib3d230d.lib")
	#pragma comment(lib,"opencv_features2d230d.lib")
	#pragma comment(lib,"opencv_gpu230d.lib")
	#pragma comment(lib,"opencv_video230d.lib")
	#pragma comment(lib,"opencv_objdetect230d.lib")
#else
	//Release���[�h�̏ꍇ
	#pragma comment(lib,"opencv_core230.lib")
	#pragma comment(lib,"opencv_imgproc230.lib")
	#pragma comment(lib,"opencv_highgui230.lib")
	#pragma comment(lib,"opencv_calib3d230.lib")
	#pragma comment(lib,"opencv_features2d230.lib")
	#pragma comment(lib,"opencv_gpu230.lib")
	#pragma comment(lib,"opencv_video230.lib")
	#pragma comment(lib,"opencv_objdetect230.lib")
#endif



/*/
#include <cv.h>
#include <cxcore.h>
#include <cvaux.h>
#include <highgui.h>

#ifdef _DEBUG
	#pragma comment(lib,"cv210d.lib")
	#pragma comment(lib,"cxcore210d.lib")
	#pragma comment(lib,"cvaux210d.lib")
	#pragma comment(lib,"highgui210d.lib")
#else
	#pragma comment(lib,"cv210.lib")
	#pragma comment(lib,"cxcore210.lib")
	#pragma comment(lib,"cvaux210.lib")
	#pragma comment(lib,"highgui210.lib")
#endif
//*/


/**********************************************
    double t = (double)getTickCount();

    t = (double)getTickCount() - t;
    printf("tdetection time = %gms\n", t*1000./cv::getTickFrequency());
***********************************************/


template<typename T, int cn> void PrintMat(const cv::Mat &m, int flag = 0){
	if(flag == 0){
		for(int y = 0; y < m.rows; y++){
			for(int x = 0; x < m.cols; x++){
				std::cout << m.at< cv::Vec<T,cn> >(y,x);
			}
			std::cout << std::endl;
		}
	}else{
		for(int x = 0; x < m.cols; x++){
			for(int y = 0; y < m.rows; y++){
				std::cout << m.at< cv::Vec<T,cn> >(y,x);
			}
			std::cout << std::endl;
		}
	}
}


static void MatDetail(const cv::Mat &m){
	printf("CHANNEL : %d, DEPTH : %d\n", m.channels(), m.depth());
	printf("%d�s%d��\n\n", m.rows, m.cols);
}

static size_t MatDataLength(const cv::Mat &m){
	return m.cols*m.rows*m.elemSize();
}

#ifndef __OPENCV_CORE_OPERATIONS_HPP__
template<typename T> inline std::ostream& operator<<(std::ostream &ost, const cv::Point_<T> &p){
	ost << p.x << " , " << p.y;
	return ost;
}

template<typename T> inline std::ostream& operator<<(std::ostream &ost, const cv::Point3_<T> &p){
	ost << p.x << " , " << p.y << " , " << p.z;
	return ost;
}
#endif

template<typename T, int cn> inline std::ostream& operator<<(std::ostream &ost, const cv::Vec<T, cn> &vec){
	ost << (int)vec[0];
	for(int i = 1; i < cn; i++)
		ost << " " << (int)vec[i];
	return ost;
}

template<typename T> inline std::ostream& operator<<(std::ostream &ost, const cv::Rect_<T> &rect){
	ost << rect.x << " , " << rect.y << " , " << rect.width << " , " << rect.height;
	return ost;
}

template<typename T> inline std::ostream& operator<<(std::ostream &ost, const cv::Size_<T> &size){
	ost << size.width << " , " << size.height;
	return ost;
}
